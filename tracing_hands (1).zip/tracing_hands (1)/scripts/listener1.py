#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import rospy
from  tracing_hands.msg import int_list_1d,int_list_2d
import cv2 as cv
import numpy as np
import os

winName = 'hand tracer'

def drawPred( frame,left, top, right, bottom):
    # Draw a bounding box.

    center_point = ( int( left+( right-left )/2 ), int( top+( bottom-top )/2 ) ) #calculate center bounding box 
    cv.rectangle(frame, (left, top), (right, bottom), (255, 178, 50), 3) #draw rectangele
    cv.circle( frame, center_point, 1, (255,0,0), 4  ) #draw point
    cv.putText(frame, ( '(%d,%d)'%center_point ), center_point, cv.FONT_HERSHEY_SIMPLEX, 0.75, (255,0,0), 1) #draw croodnates

def callback(data):
    msg_length = len( data.data )
    row = data.row
    col  = data.col
    channel = data.channel

    #print( 'str=',str(data.image),'/n' )
    current_image =  list( str(data.image)[1:-1].split(',') )
    current_image = list( int(x) for x in current_image)
    #print( 'list=',current_image,'/n' )
    #get image from talker
    #msg_image = np.array( current_image,dtype=np.uint8 ).reshape( row,col,channel ) 
    msg_image = np.zeros( ( row, col ) )
    
    if msg_length == 0:
        return
    #change type masg in int_list_2d，generate to python with type list
    else:
        msg_2d = []
        for i in range( msg_length ):
            list_1d = str(data.data[i])
            list_1d = list( list_1d[7:-1].split( ',' ) )
            list_1d = list( int(x) for x in list_1d)
            msg_2d .append( list_1d )
            drawPred( msg_image, list_1d[0], list_1d[1], list_1d[2],list_1d[3] )
  
    '''boudning box [ left,top,right,bottom ]'''
    #rospy.loginfo(rospy.get_caller_id() + "I receive  %s"%msg_2d) # msg_2d type with list

    
    cv.namedWindow(winName, cv.WINDOW_NORMAL)
    cv.imshow(winName, msg_image)
    if cv.waitKey(40) & 0xFF == ord('q'):
        cap.release()
    return

def listener():
    rospy.init_node(  'listener1', anonymous=True )
    rospy.Subscriber("chatter", int_list_2d, callback)
    rospy.spin()

if __name__ == '__main__':
    
    listener()
