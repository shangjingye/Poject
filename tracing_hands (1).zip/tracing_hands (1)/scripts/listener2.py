#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import rospy
from  tracing_hands.msg import int_list_1d,int_list_2d
import cv2 as cv
import numpy as np
from handPoseImage import hand_key_points
import os
import time

winName = 'hand key points tracer'

def callback(data):
    msg_length = len( data.data )
    row = data.row
    col  = data.col
    channel = data.channel

    current_image =  list( str(data.image)[1:-1].split(',') )
    current_image = list( int(x) for x in current_image)
    #get image from msg2
    msg_image = np.array( current_image,dtype=np.uint8 ).reshape( row,col,channel ) #change image type to np.uint8
    
    #if there is no hand 
    if msg_length == 0: 
        return
    #get key point to the hand 
    else: 
        #get area of dected hand ，[left, top, right, bottom]
        msg_2d = []
        for i in range( msg_length ):
            list_1d = str(data.data[i])
            list_1d = list( list_1d[7:-1].split( ',' ) )
            list_1d = list( int(x) for x in list_1d)
            msg_2d .append( list_1d )

        hands_roi = msg_image[ msg_2d[0][1]:msg_2d[0][3], msg_2d[0][0]:msg_2d[0][2],:3] 
        row =   msg_2d[0][3] - msg_2d[0][1]
        col =   msg_2d[0][2] - msg_2d[0][0]
        key_poins_img = hand_key_points( hands_roi, row, col  ) 
    '''output bounding box [ left,top,right,bottom ]'''
    #rospy.loginfo(rospy.get_caller_id() + "I receive  %s"%msg_2d) # msg_2d type list
    #see the result
    cv.namedWindow(winName, cv.WINDOW_NORMAL)
    cv.imshow(winName, key_poins_img)
    if cv.waitKey(40) & 0xFF == ord('q'):
        cap.release()
    return

def listener():
    rospy.init_node(  'listener2', anonymous=True )
    rospy.Subscriber("chatter", int_list_2d, callback)
    rospy.spin()

if __name__ == '__main__':
    
    listener()
