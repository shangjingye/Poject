#!/usr/bin/python3
# -*- coding: UTF-8 -*-
#this code modyfly by reference link :https://www.learnopencv.com/deep-learning-based-object-detection-using-yolov3-with-opencv-python-c/
import cv2 as cv
import argparse
import sys
import numpy as np
import os.path
import os
import time
import json

'''import message type'''
from  tracing_hands.msg import int_list_1d,int_list_2d
import rospy

# Initialize the parameters
confThreshold = 0.0  #Confidence threshold
nmsThreshold = 0.4   #Non-maximum suppression threshold
#inpWidth = 608       #Width of network's input image
#inpHeight = 608     #Height of network's input image

inpWidth = 320      #Width of network's input image，
inpHeight = 320    #Height of network's input image

modelConfiguration =os.path.join( '/home/tonyshang/Desktop/project/final/tracing_hands/config/train.cfg')
modelWeights = os.path.join( '/home/tonyshang/Desktop/project/final/tracing_hands/config/final.weights')

'''set up src for weight and cofig file'''



net = cv.dnn.readNetFromDarknet(modelConfiguration, modelWeights)
net.setPreferableBackend(cv.dnn.DNN_BACKEND_OPENCV)
# net.setPreferableBackend(cv.dnn.DNN_TARGET_OPENCL)
net.setPreferableTarget(cv.dnn.DNN_TARGET_CPU) #could switch to GPU,cv.dnn.DNN_TARGET_OPENCL，


# Get the names of the output layers
def getOutputsNames(net):
    # Get the names of all the layers in the network
    layersNames = net.getLayerNames()
    # Get the names of the output layers, i.e. the layers with unconnected outputs
    return [layersNames[i[0] - 1] for i in net.getUnconnectedOutLayers()]

# Draw the predicted bounding box
def drawPred(frame,classId, conf, left, top, right, bottom):
    # Draw a bounding box.
    cv.rectangle(frame, (left, top), (right, bottom), (255, 178, 50), 3)


    label = 'hand'

    #Display the label at the top of the bounding box
    labelSize, baseLine = cv.getTextSize(label, cv.FONT_HERSHEY_SIMPLEX, 0.5, 1)
    top = max(top, labelSize[1])
    cv.rectangle(frame, (left, top - round(1.5*labelSize[1])), (left + round(1.5*labelSize[0]), top + baseLine), (255, 255, 255), cv.FILLED)
    cv.putText(frame, label, (left, top), cv.FONT_HERSHEY_SIMPLEX, 0.75, (0,0,0), 1)

# Remove the bounding boxes with low confidence using non-maxima suppression
def postprocess(frame, outs):
    frameHeight = frame.shape[0]
    frameWidth = frame.shape[1]

    '''inital msg2 type'''
    list_2d = int_list_2d(  )

    classIds = []
    confidences = []
    boxes = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            classId = np.argmax(scores)
            confidence = scores[classId]
            if confidence > confThreshold:
                center_x = int(detection[0] * frameWidth)
                center_y = int(detection[1] * frameHeight)
                width = int(detection[2] * frameWidth)
                height = int(detection[3] * frameHeight)
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)
                classIds.append(classId)
                confidences.append(float(confidence))
                boxes.append([left, top, width, height])

    # Perform non maximum suppression to eliminate redundant overlapping boxes with
    # lower confidences.
    indices = cv.dnn.NMSBoxes(boxes, confidences, confThreshold, nmsThreshold)

    for i in indices:
        i = i[0]
        box = boxes[i]
        left = box[0]
        top = box[1]
        width = box[2]
        height = box[3]

        '''返回,left,top,right,bottom,根据左上角点(left,top)和右下角点，得到矩形框'''
        list_1d = int_list_1d( data =   [ left,top,left+width,top+height ] )
        list_2d.data.append(  list_1d ) #msg2 include all type of msg1

        drawPred(frame,classIds[i], confidences[i], left, top, left + width, top + height)
    
    #return msg2
    return  list_2d 


def main(  ):
    '''inital cofig'''
    pub = rospy.Publisher('chatter', int_list_2d, queue_size=10) # id with chatter

    rospy.init_node('talker', anonymous=True) # inital node name with talker
    rate = rospy.Rate(10)  # 10 times per second

    # Process inputs
    winName = 'hand detect'
    cv.namedWindow(winName, cv.WINDOW_NORMAL)

    # Webcam input
    #cap = cv.VideoCapture(0)
    '''change input to your src'''
    cap = cv.VideoCapture( '/home/tonyshang/Desktop/hand.mp4' )


    if cap.isOpened():
        hasFrame, frame = cap.read()
    else:
        hasFrame = False

    while not rospy.is_shutdown() and hasFrame: 
        # get frame from the video
        hasFrame, frame = cap.read()

        # Stop the program if reached end of video
        if not hasFrame:
            print("camera open error")
            cv.waitKey(300)
            break

        # Create a 4D blob from a frame.
        blob = cv.dnn.blobFromImage(frame, 1/255, (inpWidth, inpHeight), [0,0,0], 1, crop=False)

        #blob = cv.dnn.blobFromImage(frame, 1/255, (inpWidth, inpHeight), [0,0,0], 1, crop=False)

        # Sets the input to the network
        net.setInput(blob)

        # Runs the forward pass to get output of the output layers
        outs = net.forward(getOutputsNames(net))

        '''send messge'''
        # Remove the bounding boxes with low confidence
        send_msg = postprocess(frame, outs)
 
         #frame = frame[:5,:5,:3]
        send_msg.row, send_msg.col,send_msg.channel =  frame.shape #get msg and channel
        msg_image = frame.copy()
        msg_image = list(msg_image.flatten()) 
        send_msg.image = msg_image #get msg
        #print( send_msg.image )
        if( len( send_msg.data ) ):
            pub.publish(send_msg)

            #print msg data
            print( rospy.get_caller_id() + "I send  %s"%send_msg.data )

        rate.sleep()

        cv.imshow(winName, frame)
        if cv.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()

if  __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        pass

